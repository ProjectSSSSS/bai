import tkinter as tk
from matplotlib import pyplot as plt
from tkinter import ttk
import numpy as np
class deal():
    def __init__(self):
        self.type=''
        self.price=''
    def go(self,*args):
        self.type=choseType.get()
    def show(self):
        #self.price=price
        l1=[]
        l2=[]
        l3=[]
        x=0
        l4=[]
        f=open(".\数据集部分\data1.txt")#2为type 4为price
        f1=open(".\数据集部分\索菲亚1.txt")#3为prince
        f2=open(".\数据集部分\尚品宅配1.txt")#2为类型 4为price

        for i in f:
            data=i.strip('\n').split('\t')
            if int(data[5])<int(var1.get()) and data[3]==var.get() :
                l1.append(data[0])
                l1.append(data[1])
                l1.append(data[2])
                l1.append(data[3])
                l1.append(data[4])
                l1.append(data[5])

                l2.append(l1)
                x+=1
                if x%5==0:
                    l3.append(int(data[0]))
                    l4.append(int(data[5]))

        ll=l3
        lll=l4
        l3=np.array(l3)
        l4=np.array(l4)
        plt.scatter(l3,l4,c=l3)
        plt.xticks(np.arange(0,ll[-1],4))
        plt.yticks(np.arange(0,var1.get()*3,var1.get()/4))
        plt.show()
    def analy(self):
        l1 = []
        l2 = []
        l3 = []
        x = 0
        l4 = []
        f = open(".\数据集部分\data1.txt")  # 2为type 4为price
        f1 = open(".\数据集部分\索菲亚1.txt")  # 3为prince
        f2 = open(".\数据集部分\尚品宅配1.txt")  # 2为类型 4为price

        for i in f:
            data = i.strip('\n').split('\t')

            l3.append(int(data[0]))
            l4.append(int(data[5]))
            #l2.append(int(data[3]))
        ll = l3
        lll = l4
        #print(l3)
        l3 = np.array(l3)
        l4 = np.array(l4)
        plt.scatter(l3, l4, c=l3)
        plt.show()

    def max(self):
        l1 = []
        l2 = []
        l3 = []
        x = 0
        l4 = []
        f = open(".\数据集部分\data1.txt")  # 2为type 4为price
        f1 = open(".\数据集部分\索菲亚1.txt")  # 3为prince
        f2 = open(".究\数据集部分\尚品宅配1.txt")  # 2为类型 4为price
        dc = {}
        for i in range(84):
            dc[i] = 0
        for i in f:
            data = i.strip('\n').split('\t')

            l3.append(int(data[0]))
            l4.append(int(data[5]))
            if dc[int(data[0])] < int(data[5]):
                dc[int(data[0])] = int(data[5])
            # l2.append(int(data[3]))

        plt.bar(range(84),[dc[i] for i in range(84)] )
        plt.show()





if __name__ == '__main__':

    window=tk.Tk()
    window.title('基于大数据的日照市家具行业的需求分析与实证研究')
    window.geometry("400x300")
    d=deal()
    var=tk.StringVar()
    l1=tk.Label(window,text='请输入要查询的家具类型').place(x=10,y=10)
    choseType=ttk.Combobox(window,width=12,textvariable=var)
    choseType.place(x=150,y=10)
    choseType['values']=('居家日用','卧室','家具饰品','布艺织物','床上用品','地板','墙地面材料','卫浴用品','灯饰照明','阳台','儿童房','书房','餐厅','客厅')
    #choseType['values']=('1','2','3')
    choseType.current(0)
    choseType.bind("<<ComboboxSelected>>",d.go)
    var1=tk.IntVar()
    l2=tk.Label(window,text='请输入理想的最高价格').place(x=10,y=60)
    entry_price=tk.Entry(window,textvariable=var1)
    entry_price.place(x=150,y=60)
    #l2=tk.Label(window,text='').place(x=10,y=30)




    button1=tk.Button(window,text='获取日照价格分布情况',command=d.show)
    button1.place(x=30,y=160)
    button2=tk.Button(window,text='日照家具数据对比',command=d.analy)
    button2.place(x=200,y=160)
    button3 = tk.Button(window, text='日照家具最高价格分析', command=d.max)
    button3.place(x=30, y=230)


    window.mainloop()

