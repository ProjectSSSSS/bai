import pymysql
f1=open(".\数据集部分\Alldata.txt",'r')
f2=open(".\数据集部分\尚品宅配1.txt")
f3=open(".\数据集部分\索菲亚1.txt")
#li=[f1,f2,f3]
con=pymysql.connect(host='localhost',port=3306,user='root',password='19930307',db='rizhaojiaju',charset='utf8')
cur=con.cursor()

#sql执行
for i in f3:
    print(111)
    data=i.strip('\n').split('\t')
    print(len(data))
    a1=[]
    sql="insert into suofeiya values('"+str(data[0])+"','"+str(data[1])+"','"+str(data[3])+"',"+str(data[4])+",null);"
    print(sql)
    cur.execute(sql)
    con.commit()
cur.close()
con.close()

f1.close()
f2.close()
f3.close()
