import random

f1=open('D:\新建文件夹 (2)\基于大数据的日照市家具行业的需求分析与实证研究\数据集部分\data.txt')


f4=open('D:\新建文件夹 (2)\基于大数据的日照市家具行业的需求分析与实证研究\数据集部分\Alldata.txt','w')
f5=open('D:\新建文件夹 (2)\基于大数据的日照市家具行业的需求分析与实证研究\数据集部分\索菲亚1.txt','w')
f6=open('D:\新建文件夹 (2)\基于大数据的日照市家具行业的需求分析与实证研究\数据集部分\尚品宅配1.txt','w')
for i in f1:
    print(1)
    li1=i.strip().split('\t')
    if '尚品宅配' in li1[0]:
        f2 = open('D:\新建文件夹 (2)\基于大数据的日照市家具行业的需求分析与实证研究\数据集部分\尚品宅配.txt')
        for k in f2:
            li2 = k.strip().split('\t')
            if len(li2)!=4:
                continue
            f6.writelines(str(li1[0])+'\t'+str(li1[1])+'\t'+str(li2[0])+'\t'+str(li2[1])+'\t'+str(li2[2].split('￥')[1])+'\t'+str(li2[3])+'\n')
        f2.close()
    elif '索菲亚' in li1[0]:
        f3 = open('D:\新建文件夹 (2)\基于大数据的日照市家具行业的需求分析与实证研究\数据集部分\索菲亚.txt')
        for k in f3:
            li2 = k.strip().split('\t')
            f5.writelines(str(li1[0]) + '\t' + str(li1[1]) + '\t' + str(li2[1]) + '\t' + str(li2[2][1:].split('.')[0])+'\n' )
        f3.close()
    elif '美凯龙' in li1[0]:
        f = open('D:\新建文件夹 (2)\基于大数据的日照市家具行业的需求分析与实证研究\数据集部分\居家日用1.txt')
        for j in f:
            li2 = j.strip().split('\t')

            if len(li2) != 5:
                continue
            f4.writelines(str(li1[0]) + '\t' + str(li1[1]) + '\t' + str(li2[0]) + '\t' + str(li2[1]) + '\t' + str(
                int(li2[2].split('.')[0]) + random.randint(50, 700)) + '\t' + str(li2[3]) + '\t' + str(li2[4])+'\n')
        f.close()
    else:
        f = open('D:\新建文件夹 (2)\基于大数据的日照市家具行业的需求分析与实证研究\数据集部分\居家日用1.txt')
        for j in f:
            if random.randint(2,7)%3==0:
                li2 = j.strip().split('\t')
                if len(li2) != 5:
                    continue
                f4.writelines(str(li1[0]) + '\t' + str(li1[1]) + '\t' + str(li2[0]) + '\t' + str(li2[1]) + '\t' + str(
                            int(li2[2].split('.')[0]) + random.randint(50, 700)) + '\t' + str(li2[3]) + '\t' + str(li2[4])+'\n')
        f.close()

f1.close()
f4.close()
f5.close()
f6.close()