# -*- coding: utf-8 -*-
import scrapy
from Furniture.items import FurnitureItem
import time
class InformationSpider(scrapy.Spider):
    name = 'information'
    allowed_domains = ['meilele.com']
    start_urls = ['https://www.meilele.com/category-jiajujiazhuang/list-p1/?from=page#p']
    def __init__(self):
        self.s1=2
    def parse(self, response):
        item=FurnitureItem()
        data=response.xpath('//*[@id="JS_list_panel"]/div/ul/li')
        for i in data:
            temp=i.xpath('div[2]/div[3]/strong/span/text()').extract()

            # if len(temp)!=0:
            #     item['name']=temp[0]
            #     item['price']=i.xpath('h4/span/text()').extract()[0]
            #     item['type']=i.xpath('h4/text()[2]').extract()[0]
            #     yield item
            if len(temp)==0:
                item['price']=i.xpath('div/div[3]/strong/span/text()').extract()[0]
                item['name']=i.xpath('div/a[2]/span[1]/text()').extract()[0]
            else:
                item['price']=temp[0]
                item['name']=i.xpath('div[2]/a[2]/span[1]/text()').extract()[0]
            yield item
        next_url='https://www.meilele.com/category-jiajujiazhuang/list-p'+str(self.s1)+'/?from=page#p'
        self.s1+=1
        #time.sleep(2)
        yield scrapy.Request(next_url,callback=self.parse)
