# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html


class FurniturePipeline(object):
    def process_item(self, item, spider):
        print(11111)
        with open('D:\spider\Furniture\居家日用1.txt','a') as f:
            list1=item['name'].split('\xa0')
            print(list1)
            list2=list1[0].split('\t\t\t\t\t')
            f.writelines('居家日用'+'\t'+str(list1[1])+'\t'+str(item['price'])+'\t'+str(list2[0])+'\t'+str(list2[1])+'\n')
        return item
