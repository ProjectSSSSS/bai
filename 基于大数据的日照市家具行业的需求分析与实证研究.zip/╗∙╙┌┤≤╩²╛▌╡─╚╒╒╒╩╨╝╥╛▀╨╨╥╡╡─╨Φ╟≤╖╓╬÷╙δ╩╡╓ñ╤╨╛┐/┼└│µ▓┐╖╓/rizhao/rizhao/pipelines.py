# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html


class RizhaoPipeline(object):
    def process_item(self, item, spider):
        x=0
        with open("market_data.txt",'a') as f:
            if x==0:
                x+=1
                f.write("家具商城名称"+"\t"+"地址"+'\n')
            f.write(item['name']+'\t'+item['addr']+'\n')

        return item
