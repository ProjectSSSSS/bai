# -*- coding: utf-8 -*-
import scrapy
from rizhao.items import RizhaoItem

class JiajuSpider(scrapy.Spider):
    name = 'jiaju'
    #allowed_domains = ['sogou.com']
    start_urls = ['http://map.sogou.com/#c=13267732,4216231,10&lq=%u65E5%u7167%u5BB6%u5177&where=13200000,4170062.5,13335250,4262437.5,0&page=1,10']
    # f=open("../data/url.txt")
    # list1=[]
    # for i in f:
    #     list1.append(i)
    # f.close()
    def __init__(self):
        f = open("../data/url.txt")
        self.list1 = []
        for i in f:
            self.list1.append(i)
        f.close()
    def parse(self, response):
        #item=RizhaoItem()
        data = response.xpath('//*[@id="searchResult"]/div[1]/div[7]/div')
        # print(22222)
        print(data)
        for i in self.list1:
            yield scrapy.Request(i,callback=self.parse1)
    def parse1(self,response):
        #print(1111)
        item=RizhaoItem()
        data=response.xpath('//*[@id="searchResult"]/div[1]/div[7]/div')
        #print(22222)
        print(data)
        for i in data:
            item['name']=i.xpath('div/div[2]/div[1]/span/text()').extract()[0]
            #item['tel']=i.xpath('div/div[2]/div[6]/text()').extract()[0]
            item['addr']=i.xpath('div/div[2]/div[8]/text()').extract()[0]
            yield item