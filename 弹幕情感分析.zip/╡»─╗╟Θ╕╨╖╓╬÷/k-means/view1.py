# encoding:utf-8
import tkinter as tk
from tkinter import filedialog
import emotion_bullet
import pandas as pd


global negative
global path
def selectPath():

    global path
    path=filedialog.askopenfilename()


def emotional():
    global negative
    negative=[]
    negative.append(emotion_bullet.main1(path))
    print(negative)

def filter():

    df=pd.read_csv('bt.csv')
    f=open('ne.txt')
    scentence=[]
    for i in f:
        print(i)
        i=int(i)
        a=list(df.loc[i:i]['comment'])
        print(a)
        scentence.append(a)
    root = tk.Tk()
    text = tk.Text(root, width=500, height=500)
    text.pack()
    print(scentence)
    for sce in scentence[:-1]:
        text.insert(tk.INSERT, sce[0]+'\n')  # INSERT索引表示光标当前的位置
    #text.insert(tk.END,scentence[-1])
    root.mainloop()
def window():
    window = tk.Tk()
    # 这里可以自己修改标题名称
    window.title('基于K-means的弹幕分析')
    window.geometry('600x300')

    tk.Label(window, text='基于K-means的弹幕分析', font=("黑体", 20, "bold")).place(x=150, y=30)
    path = tk.StringVar()
    tk.Label(window, text="目标路径:").place(x=60, y=90)
    tk.Entry(window, textvariable=path, width=40).place(x=160, y=90)
    tk.Button(window, text="路径选择", command=selectPath).place(x=500, y=90)

    tk.Button(window, text="弹幕情感分析", command=emotional).place(x=60, y=160)
    tk.Button(window, text="过滤弹幕显示", command=filter).place(x=260, y=160)
    window.mainloop()

window()
