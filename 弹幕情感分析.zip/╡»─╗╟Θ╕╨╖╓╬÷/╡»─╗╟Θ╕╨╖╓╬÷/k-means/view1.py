# encoding:utf-8
import tkinter as tk
from tkinter import filedialog
import emotion_bullet
import pandas as pd
import mysql
import matplotlib.pyplot as plt
from wordcloud import WordCloud,ImageColorGenerator
import jieba


global negative
global path_
global path
global content
global content1
global content2
global content3
global db
global cursor

global e
def selectPath():

    global path_
    global path
    path_=filedialog.askopenfilename()
    path.set(path_)

def emotional():
    global negative
    negative=[]
    negative.append(emotion_bullet.main1(path_))
    print(negative)
def show():
    global path_
    text_all = emotion_bullet.parseXml1(path_)
    font = 'Tensentype-DouDouJ.ttf'
    wc = WordCloud(scale=20,
                   background_color='white',
                   max_words=1000,
                   font_path=font,
                   random_state=15)
    word_list = []
    word_generator = jieba.cut(text_all, cut_all=False)
    for word in word_generator:
        if word not in word_list:
            word_list.append(word)
    text = ' '.join(word_list)
    print(text)
    wc.generate(text)
    plt.figure(figsize=(20, 10))
    plt.axis('off')
    plt.imshow(wc)
    plt.show()

def filter():

    df=pd.read_csv('bt.csv')
    f=open('ne.txt')
    scentence=[]
    for i in f:
        print(i)
        i=int(i)
        a=list(df.loc[i:i]['comment'])
        print(a)
        scentence.append(a)
    root = tk.Tk()
    text = tk.Text(root, width=500, height=500)
    text.pack()
    print(scentence)
    for sce in scentence[:-1]:
        text.insert(tk.INSERT, sce[0]+'\n')  # INSERT索引表示光标当前的位置
    #text.insert(tk.END,scentence[-1])
    root.mainloop()
def save():
    global db
    global cursor
    global path_
    db,cursor=mysql.create_data()
    text=emotion_bullet.parseXml(path_)

    tdata=text.split('-a-a-')[:-1]
    #print(tdata)
    for i in tdata:
        mysql.insert_data(i,db,cursor)
    print("存储成功")
def sel():
    mysql.sel_data(db,cursor)
def deld():
    global db
    global cursor
    global content1
    mysql.del_data(content1.get(),db,cursor)

def add():
    global db
    global cursor
    global content
    mysql.insert_data(content.get(),db,cursor)
def mod():
    global db
    global cursor
    global content2
    global content3
    mysql.mod_data(content2.get(),content3.get(),db,cursor)
def window():
    global path
    global content
    global content1
    global content2
    global content3
    window = tk.Tk()
    # 这里可以自己修改标题名称
    window.title('基于K-means的弹幕分析')
    window.geometry('600x400')

    tk.Label(window, text='基于K-means的弹幕分析', font=("黑体", 20, "bold")).place(x=150, y=30)
    path = tk.StringVar()
    tk.Label(window, text="目标路径:").place(x=60, y=90)
    e=tk.Entry(window, textvariable=path, width=40)
    e.place(x=160, y=90)
    tk.Button(window, text="路径选择", command=selectPath).place(x=500, y=90)

    tk.Button(window, text="弹幕情感分析", command=emotional).place(x=30, y=120)
    tk.Button(window, text="过滤弹幕显示", command=filter).place(x=130, y=120)
    tk.Button(window, text="  存储弹幕  ", command=save).place(x=230, y=120)
    tk.Button(window, text=" 查询所有弹幕 ", command=sel).place(x=330, y=120)
    tk.Button(window, text="   词云显示   ", command=show).place(x=460, y=120)
    content=tk.StringVar()
    content2 = tk.StringVar()
    tk.Label(window, text="请输入增加弹幕内容").place(x=60, y=180)
    tk.Entry(window, textvariable=content, width=40).place(x=180, y=180)
    tk.Button(window, text="  增加弹幕  ", command=add).place(x=470, y=180)
    tk.Label(window, text="请输入需要修改弹幕内容").place(x=60, y=230)
    tk.Entry(window, textvariable=content2, width=40).place(x=240, y=230)
    tk.Label(window, text="请输入需要修改弹幕内容").place(x=60, y=230)
    tk.Entry(window, textvariable=content2, width=40).place(x=240, y=230)
    content3 = tk.StringVar()
    tk.Label(window, text="请输入修改后的弹幕内容").place(x=60, y=270)
    tk.Entry(window, textvariable=content3, width=40).place(x=240, y=270)
    tk.Button(window, text="  修改弹幕  ", command=mod).place(x=270, y=300)
    content1 = tk.StringVar()
    tk.Label(window, text="请输入删除弹幕内容").place(x=60, y=340)
    tk.Entry(window, textvariable=content1, width=40).place(x=180, y=340)
    tk.Button(window, text="  删除弹幕  ", command=deld).place(x=470, y=340)
    window.mainloop()

window()
