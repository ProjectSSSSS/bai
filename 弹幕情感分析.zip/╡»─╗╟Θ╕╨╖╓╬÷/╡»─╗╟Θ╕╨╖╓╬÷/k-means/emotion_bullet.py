# encoding:utf-8
import jieba
import numpy as np
import xml.etree.ElementTree as ET
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.externals import joblib
from  matplotlib import pyplot as plt
from  sklearn.preprocessing import MinMaxScaler

def parseXml(file):
    text_all=''
    tree=ET.parse(file)

    root=tree.getroot()
    for child in root:
        #print(child)
        if child.tag=='d':
            text_all=text_all+child.text+'-a-a-'
    return text_all



#打开词典文件，返回列表
def open_dict(Dict = '', path=''):
    path = path + '%s.txt' % Dict
    dictionary = open(path, 'r', encoding='utf-8')
    dict = []
    for word in dictionary:
        word = word.strip('\n')
        dict.append(word)
    return dict


def sent2word(sentence,stop_all):
    seglist = jieba.cut(sentence)
    segResult = []
    for w in seglist:
        segResult.append(w)
    newSent = []
    #如果词汇是在停用词中，则过滤掉
    for word in segResult:
        if word in stop_all:
            continue
        else:
            newSent.append(word)
    return newSent

def judgeodd(num):
    if (num % 2) == 0:
        return 'even'
    else:
        return 'odd'

def parseXml1(file):
    text_all = ''''''
    tree = ET.parse(file)
    #获取节点
    root = tree.getroot()
    for child in root:
        if child.tag == 'd':
            text_all = text_all + child.text
    return text_all





def sentiment_score_list(dataset,posdict,mostdict,verydict,moredict,ishdict,deny_word,negdict,degree_word):
    seg_sentence=dataset

    count1 = []
    count2 = []
    for sen in seg_sentence: #循环遍历每一个评论
        segtmp = jieba.lcut(sen, cut_all=False)  #把句子进行分词，以列表的形式返回
        i = 0 #记录扫描到的词的位置
        a = 0 #记录情感词的位置
        poscount = 0 #积极词的第一次分值
        poscount2 = 0 #积极词反转后的分值
        poscount3 = 0 #积极词的最后分值（包括叹号的分值）
        negcount = 0
        negcount2 = 0
        negcount3 = 0
        for word in segtmp:
            if word in posdict:  # 判断词语是否是情感词
                poscount += 1
                c = 0
                for w in segtmp[a:i]:  # 扫描情感词前的程度词
                    if w in mostdict:
                        poscount *= 4.0
                    elif w in verydict:
                        poscount *= 3.0
                    elif w in moredict:
                        poscount *= 2.0
                    elif w in ishdict:
                        poscount *= 0.5
                    elif w in deny_word:
                        c += 1
                if judgeodd(c) == 'odd':  # 扫描情感词前的否定词数
                    poscount *= -1.0
                    poscount2 += poscount
                    poscount = 0
                    poscount3 = poscount + poscount2 + poscount3
                    poscount2 = 0
                else:
                    poscount3 = poscount + poscount2 + poscount3
                    poscount = 0
                a = i + 1  # 情感词的位置变化

            elif word in negdict:  # 消极情感的分析，与上面一致
                negcount += 1
                d = 0
                for w in segtmp[a:i]:
                    if w in mostdict:
                        negcount *= 4.0
                    elif w in verydict:
                        negcount *= 3.0
                    elif w in moredict:
                        negcount *= 2.0
                    elif w in ishdict:
                        negcount *= 0.5
                    elif w in degree_word:
                        d += 1
                if judgeodd(d) == 'odd':
                    negcount *= -1.0
                    negcount2 += negcount
                    negcount = 0
                    negcount3 = negcount + negcount2 + negcount3
                    negcount2 = 0
                else:
                    negcount3 = negcount + negcount2 + negcount3
                    negcount = 0
                a = i + 1
            elif word == '！' or word == '!':  ##判断句子是否有感叹号
                for w2 in segtmp[::-1]:  # 扫描感叹号前的情感词，发现后权值+2，然后退出循环
                    if w2 in posdict or negdict:
                        poscount3 += 2
                        negcount3 += 2
                        break
            i += 1 # 扫描词位置前移


            # 以下是防止出现负数的情况
            pos_count = 0
            neg_count = 0
            if poscount3 < 0 and negcount3 > 0:
                neg_count += negcount3 - poscount3
                pos_count = 0
            elif negcount3 < 0 and poscount3 > 0:
                pos_count = poscount3 - negcount3
                neg_count = 0
            elif poscount3 < 0 and negcount3 < 0:
                neg_count = -poscount3
                pos_count = -negcount3
            else:
                pos_count = poscount3
                neg_count = negcount3

            count1.append([pos_count, neg_count])
        count2.append(count1)
        count1 = []

    return count2

def sentiment_score(senti_score_list):
    score = []
    for review in senti_score_list:
        score_array = np.array(review)
        Pos = np.sum(score_array[:, 0])
        Neg = np.sum(score_array[:, 1])
        AvgPos = np.mean(score_array[:, 0])
        AvgPos = float('%.1f'%AvgPos)
        AvgNeg = np.mean(score_array[:, 1])
        AvgNeg = float('%.1f'%AvgNeg)
        StdPos = np.std(score_array[:, 0])
        StdPos = float('%.1f'%StdPos)
        StdNeg = np.std(score_array[:, 1])
        StdNeg = float('%.1f'%StdNeg)
        score.append([Pos, Neg, AvgPos, AvgNeg, StdPos, StdNeg])
    s1=0
    s2=0
    s3=0
    s4=0
    s5=0
    s6=0
    for i in score:
        s1+=i[0]
        s2+=i[1]
        s3+=i[2]
        s4+=i[3]
        s5+=i[4]
        s6+=i[5]
    score1=[[s1,s2,s3,s4,s5,s6]]

    return score1

#数据降维使用PCA
def getFeature(data):
    pca=PCA(n_components=1)
    return pca.fit_transform(data)


def getLow(df):
    data=df[['消极','消极均值']]
    return getFeature(data)

def gethigh(df):
    data=df[['积极','积极均值']]
    return getFeature(data)


def peopleGroup(predict, id):
    '''
    分为5类人
    :return:
    '''
    id1=id.values.tolist()
    res1 = []
    res2 = []
    res3 = []
    res4 = []
    res5 = []
    for i in range(len(predict)):
        if predict[i] == 0:
            res1.append(id1[i])
        elif predict[i] == 1:
            res2.append(id1[i])
        elif predict[i] == 2:
            res3.append(id1[i])
        elif predict[i] == 3:
            res4.append(id1[i])
        elif predict[i] == 4:
            res5.append(id1[i])
    #res=[res1,res2,res3]

    return res1, res2, res3

def km_func(res_data,id):
    km = KMeans(n_clusters=3)
    model = km.fit_transform(res_data)
    joblib.dump(model, 'bullet_km.pkl')
    center = km.cluster_centers_
    print("聚类的五个中心分别为：")
    for i in range(len(center)):
        print(center[i])  # 将源数据集进行分类

    predict = km.predict(res_data)
    res1, res2, res3 = peopleGroup(predict, id)
    del_id = []
    if len(res1) <240:
        del_id.append(res1)
    if len(res2) <240:
        del_id.append(res2)
    if len(res3) < 240:
        del_id.append(res3)
    return del_id,res1,res2,res3,km,center



def main(df):
    center=[[]]
    ne_bullet=[]
    res1=""
    res2=""
    res3=""
    km=""

    for i in range(3):
        id = df['id']
        low = getLow(df)
        print(type(low))
        high = gethigh(df)
        data_all = np.append(low, high, axis=1)
        sdScaler = StandardScaler()
        res_data = sdScaler.fit_transform(data_all)

        mu,res1,res2,res3,km,center= km_func(res_data,id)
        print(mu)

        if len(mu)==0:#设置异常值的门限
            break
        else:
            ne_bullet.append(mu[0])
            df=df.drop(mu[0])


    f=open("ne.txt",'w')
    for j in ne_bullet:
        for k in j:
            #print(k)
            f.write(str(k)+'\n')

    f.close()


    c1 = center[0]
    c2 = center[1]
    c3 = center[2]
    lll = []

    if c1[0] < c2[0]:
        if c1[0] < c3[0]:
            lll.append(1)
        else:
            lll.append(3)
    else:
        if c2[0] < c3[0]:
            lll.append(2)
        else:
            lll.append(3)
    small = lll[0]-1
    lll = []
    if c1[0] < c2[0]:
        if c2[0] < c3[0]:
            lll.append(3)
        else:
            lll.append(2)
    else:
        if c1[0] < c3[0]:
            lll.append(3)
        else:
            lll.append(1)
    big = lll[0]-1
    ll=[0,1,2]
    ll.remove(big)
    ll.remove(small)

    print("*" * 20 + "以下为源数据集分类部分" + "*" * 20)
    print("第一类：\r\n一共%d人" % (len(res1)))
    print("第二类：\r\n一共%d人" % (len(res2)))
    print("第三类：\r\n一共%d人" % (len(res3)))
    #print("第四类：\r\n一共%d人" % (len(res4)))
    #print("第五类：\r\n一共%d人" % (len(res5)))
    print("*" * 50)
    #fig, (ax1,ax2) = plt.subplots(1,2,figsize=(14, 6))
    # print(res_data)
    zero_one=MinMaxScaler()
    zero_data=zero_one.fit_transform(res_data)

    # ax1.scatter(zero_data[:, 0], zero_data[:, 1], c=km.labels_.astype(np.float))
    # ax1.set_xlabel("$x_1$")
    # ax1.set_ylabel("$x_2$")
    # ax1.set_title("K-Means with $k=5$")
    #
    #
    # ax2.set_xlabel("$x_1$")
    # ax2.set_ylabel("$x_2$")
    # ax2.set_title("The user classification$")
    # plt.show()
    plt.figure(12)
    plt.subplot(221)
    plt.scatter(zero_data[:, 0], zero_data[:, 1], c=km.labels_.astype(np.float))

    plt.subplot(222)
    #plt.plot(t2, np.cos(2 * np.pi * t2), 'r--')
    labels=['','','']
    labels[ll[0]]=u'middle'
    labels[small]=u'positive'
    labels[big]=u'negative'


    #plt.bar()
    sizes = [len(res1),len(res2),len(res3)]
    colors = ['red', 'yellowgreen', 'lightskyblue']

    explode = (0, 0, 0)
    plt.pie(sizes,explode=explode,labels=labels,colors=colors,autopct='%3.2f%%',  shadow=False,  startangle=90,  pctdistance=0.6)

    plt.axis('equal')

    plt.subplot(212)
    li=[0,1,2]

    plt.bar(li,sizes,0.3)

    plt.show()


def main1(filepath):
    f = open("stopWord.txt",encoding='utf-8')
    stop_all = []
    for i in f:
        stop_all.append(i.replace('\xa0\n', ''))
    f.close()
    # 注意，这里你要修改path路径。
    deny_word = open_dict(Dict='notdict', path='')
    posdict = open_dict(Dict='positive', path='')
    negdict = open_dict(Dict='negative', path='')

    degree_word = open_dict(Dict='advDegree', path='')
    mostdict = degree_word[degree_word.index('extreme') + 1: degree_word.index('very')]  # 权重4，即在情感词前乘以4
    verydict = degree_word[degree_word.index('very') + 1: degree_word.index('more')]  # 权重3
    moredict = degree_word[degree_word.index('more') + 1: degree_word.index('ish')]  # 权重2
    ishdict = degree_word[degree_word.index('ish') + 1: degree_word.index('last')]  # 权重0.5

    test_all = parseXml(filepath)
    data = test_all.split('-a-a-')[:-1]
    dic_csv={'comment':data}
    rx=pd.DataFrame(dic_csv)
    rx.to_csv('bt.csv')
    pos = []
    neg = []
    avgP = []
    avgN = []
    stdP = []
    stdN = []

    for i in data:
        i = sent2word(i,deny_word)
        x = sentiment_score_list(i,posdict,mostdict,verydict,moredict,ishdict,deny_word,negdict,degree_word)
        # print(x)
        res = sentiment_score(x)
        # print(res)
        pos.append(res[0][0])
        neg.append(res[0][1])
        avgP.append(res[0][2])
        avgN.append(res[0][3])
        stdP.append(res[0][4])
        stdN.append(res[0][5])

    id = [i for i in range(len(pos))]
    bullet_data = {'id': id, '积极': pos, '消极': neg, '积极均值': avgP, '消极均值': avgN, '积极方差': stdP, '消极方差': stdN}
    df = pd.DataFrame(bullet_data)
    df.to_csv('bullet.csv')
    main(df)



# comments_dict = {'comments': data}
# df=pd.DataFrame(comments_dict)
#df.to_csv("bullet_DWKM.csv",encoding='utf-8')
