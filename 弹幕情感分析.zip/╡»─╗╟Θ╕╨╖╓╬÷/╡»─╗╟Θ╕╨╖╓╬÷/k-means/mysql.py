import pymysql


def create_data():
    db = pymysql.connect("localhost", "账号", "密码", "kmeans", charset="utf8");
    cursor = db.cursor()

    # 创建数据存储表 这里表名为user
    print(333)
    cursor.execute("drop table if exists user")
    sql = """CREATE TABLE  user ( 
          `id` int(11) NOT NULL AUTO_INCREMENT, 
          `comments` varchar(255) NOT NULL, 
          PRIMARY KEY (`id`) 
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0"""

    cursor.execute(sql)
    return db,cursor

def insert_data(data,db,cursor):
    # data=str(data.encode("utf-8"))
    sql = "INSERT INTO `user` (`comments`) VALUES ('"+data+"')"
    # cursor.execute(sql)
    # # 提交到数据库执行
    # db.commit()
    try:
        # 执行sql语句
        cursor.execute(sql)
        # 提交到数据库执行
        db.commit()
    except:
        # 如果发生错误则回滚
        print(111)


def del_data(data,db,cursor):

    sql = "delete from user where comments='%s'" % (data)
    try:
        cursor.execute(sql)
        db.commit()
        print("删除成功")
    except:
        print("未找到此弹幕")
        db.rollback()
def mod_data(data1,data2,db,cursor):
    sql = "update user set comments='"+data2+"' where comments='%s'" % (data1)
    #print(sql)
    try:
        cursor.execute(sql)
        db.commit()
        print("修改成功")
    except:
        print("未找到要修改的内容")
        db.rollback()
def sel_data(db,cursor):
    #cursor.execute("select * from user")
    try:
        print(11)
        cursor.execute("select * from user")  # 执行sql语句
        print(22)
        results = cursor.fetchall()  # 获取查询的所有记录
        # 遍历结果
        for row in results:
            id=row[0]
            comment=row[1]
            print(id, comment)
    except Exception as e:
        raise e

