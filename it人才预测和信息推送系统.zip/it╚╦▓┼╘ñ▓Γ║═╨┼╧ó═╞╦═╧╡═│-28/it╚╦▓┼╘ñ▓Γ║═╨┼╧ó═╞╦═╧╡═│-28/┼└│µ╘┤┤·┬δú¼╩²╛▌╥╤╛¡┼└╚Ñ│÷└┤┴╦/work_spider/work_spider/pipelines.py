# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html


class WorkSpiderPipeline(object):
    def __init__(self):
        self.que=0
    def process_item(self, item, spider):
        with open("work3.txt",'a',encoding='utf-8') as f:
            if self.que==0:
                f.writelines('城市'+'\t'+'职位名称'+'\t'+'工资'+'\t'+'公司'+'\t'+'工作地点'+'\t'+'工作经验'+'\t'+'学历要求'+'\t'+'公司类型'+'\t'+'工作详情链接'+'\t'+'岗位类型'+'\t'+'岗位'+'\n')
                self.que+=1
            else:
                f.writelines(item['w_city']+'\t'+item['work_name'] + '\t' + item['salary'] + '\t' + item['company'] + '\t' + item[
                    'work_addr'] + '\t' + item['work_exp'] + '\t' + item['work_degree'] + '\t' + item[
                                 'company_type'] + '\t' + item['detial_work'] + '\t'+item['p_type'] +'\t'+ item['position'] + '\n')
        return item
        # with open('boss_postion.txt','a') as f:
        #     f.writelines(item['name']+'\t'+item['position']+'\t'+item['url']+'\n')
        # return item
        # with open('city_id.txt','a') as f:
        #     f.writelines(item['pname']+'\t'+item['cname']+'\t'+item['cid']+'\n')
        # return item