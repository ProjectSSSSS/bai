# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class WorkSpiderItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    work_name=scrapy.Field()
    salary=scrapy.Field()
    company=scrapy.Field()
    work_addr=scrapy.Field()
    work_exp=scrapy.Field()
    work_degree=scrapy.Field()
    company_type=scrapy.Field()
    detial_work=scrapy.Field()
    position=scrapy.Field()
    p_type=scrapy.Field()
    w_city=scrapy.Field()

class net_work(scrapy.Item):
    name=scrapy.Field()
    position=scrapy.Field()
    url=scrapy.Field()

class city_id(scrapy.Item):
    pname=scrapy.Field()
    cname=scrapy.Field()
    cid=scrapy.Field()