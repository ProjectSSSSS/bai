# -*- coding: utf-8 -*-
import scrapy
from work_spider.items import city_id

class CityidSpiderSpider(scrapy.Spider):
    name = 'cityId_spider'
    allowed_domains = ['zhipin.com']
    start_urls = ['https://www.zhipin.com/?ka=header-home&city=101010100']
    def __init__(self):
        self.num=1
    def parse(self, response):
        item=city_id()
        xdata=response.xpath('//*[@id="header"]/div/div[2]/div/ul/li')
        for x in xdata[2:]:
            item['pname']=x.xpath('text()').extract()[0]
            self.num+=1
            hdata=response.xpath('//*[@id="header"]/div/div[2]/div/div/ul['+str(self.num)+']/li')
            for i in hdata:
                item['cname']=i.xpath('text()').extract()[0]
                item['id']=i.xpath('@data-val').extract()[0]
                yield item


