
boss=[]
ctyid=[]
city=open('city_id.txt',encoding='utf-8')
for i in city:
    cdata=i.strip('\n').split('\t')
    ctyid.append(cdata)
city.close()

for k in ctyid:

    f = open('boss_postion.txt',encoding='utf-8')

    for i in f:
        temp=[]
        data = i.strip('\n').split('\t')
        data[2] = data[2].replace('101010100',k[1])
        temp.append(k[0])
        temp.append(k[1])
        temp.append(data[0])
        temp.append(data[1])
        temp.append(data[2])
        boss.append(temp)
    f.close()
fx=open("spider_data.txt",'w',encoding='utf-8')
for i in boss:
    fx.writelines(i[0]+'\t'+i[1]+'\t'+i[2]+'\t'+i[3]+'\t'+i[4]+'\n')
fx.close()