# -*- coding: utf-8 -*-
import scrapy
from work_spider.items import net_work
import json
class WorkPSpider(scrapy.Spider):
    name = 'work_p'
    allowed_domains = ['zhipin.com']
    start_urls = ['https://www.zhipin.com/?ka=header-home&city=100010000']

    def parse(self, response):
        item=net_work()
        xdata=response.xpath('//*[@id="main"]/div/div[1]/div/dl[1]/div[2]/ul/li')
        for i in xdata:
            item['name']=i.xpath('h4/text()').extract()[0]
            x2data=i.xpath('div/a')
            for j in x2data:
                item['position']=j.xpath('text()').extract()[0]
                item['url']='https://www.zhipin.com/'+j.xpath('@href').extract()[0]
                yield item



