# -*- coding: utf-8 -*-
import scrapy
from work_spider.items import WorkSpiderItem
import time
class WspSpider(scrapy.Spider):
    name = 'wsp'
    allowed_domains = ['zhipin.com']
    start_urls = ['https://www.zhipin.com/c101300100-p101402/?page=1&ka=page-1']
    def __init__(self):
        self.x=0
        self.page=2
        #100010000
        self.boss=[]
        f=open("1.txt",encoding='utf-8')
        for i in f:
            data=i.strip('\n').split('\t')
            self.boss.append(data)
        f.close()



    def parse(self, response):

        item=WorkSpiderItem()
        xdata=response.xpath('//*[@id="main"]/div/div[2]/ul/li')
        for i in xdata:
            item['work_name']=i.xpath('div/div[1]/h3/a/div[1]/text()').extract()[0]
            item['salary'] = i.xpath('div/div[1]/h3/a/span/text()').extract()[0]
            item['company'] = i.xpath('div/div[2]/div/h3/a/text()').extract()[0]
            item['work_addr'] = i.xpath('div/div[1]/p/text()[1]').extract()[0]
            item['work_exp'] = i.xpath('div/div[1]/p/text()[2]').extract()[0]
            item['work_degree'] = i.xpath('div/div[1]/p/text()[3]').extract()[0]
            item['company_type'] = i.xpath('div/div[2]/div/p/text()[1]').extract()[0]
            item['detial_work'] = i.xpath('div/div[1]/h3/a/@href').extract()[0]
            item['p_type']=self.boss[self.x][2]
            item['position'] = self.boss[self.x][3]
            item['w_city']=self.boss[self.x][0]
            yield item
        if self.page<4:
            next_url = self.boss[self.x][4]+'?page=' + str(self.page) + '&ka=page-' + str(self.x)
            self.page += 1
            #time.sleep(3)
            yield scrapy.Request(next_url, callback=self.parse)
        else:
            self.page=2
            self.x+=1
        yield scrapy.Request(self.boss[self.x][4],callback=self.parse)



