f=open("work3.txt",encoding='utf-8')
temp=[]
for i in f:

    if i not in temp:
        temp.append(i)
f1=open("data_all.txt",'w',encoding='utf-8')
for i in temp:
    f1.writelines(i)
f1.close()