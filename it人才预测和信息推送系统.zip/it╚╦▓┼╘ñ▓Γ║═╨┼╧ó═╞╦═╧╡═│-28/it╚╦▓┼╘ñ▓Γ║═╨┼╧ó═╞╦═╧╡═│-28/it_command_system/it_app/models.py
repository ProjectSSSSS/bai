from django.db import models

# Create your models here.
class Host(models.Model):
	question=models.CharField(max_length=50)


class Answer(models.Model):
	result=models.CharField(max_length=1000)
