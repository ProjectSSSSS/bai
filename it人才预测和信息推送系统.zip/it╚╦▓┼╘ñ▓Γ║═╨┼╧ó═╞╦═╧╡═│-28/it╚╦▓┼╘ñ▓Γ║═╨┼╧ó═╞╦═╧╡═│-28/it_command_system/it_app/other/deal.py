from matplotlib import pyplot as plt
from twilio.rest import Client


def judge(minp,maxp,p_type,addr,position,number):
    f=open("D:\workplace\it_command_system\it_app\other\data_all.txt",encoding='utf-8')
    lis=[]
    lis1=[]
    lis2=[]
    lis3=[]
    lis4=[]
    lis5=[]
    lis6=[]
    lis7=[]
    lis8=[]

    xx=0
    price=[]
    #print(111)
    maxp=int(maxp)
    print(maxp)
    # print(type(maxp))
    # print(type(p_type))
    #print(p_type=='后端开发')
    # print(p_type)
    # print(position)
    # print(addr)
    for i in f:
        #print(i)

        data=i.strip('\n').split('\t')


        if addr==data[0]:
            # print(data[0] + '---' + data[-2] + '----' + data[-1])
            # print(addr + '....' + p_type + '....' + position)
            if p_type==data[-2] and position==data[-1]:

                min1=data[2].split('-')[0][:-1]
                max1=data[2].split('-')[1].split('·')[0][:-1]


                if int(max1)>=maxp and maxp>int(min1):
                    lis1.append(data[1])
                    lis2.append(data[2])
                    lis3.append(data[3])
                    lis4.append(data[4])
                    lis5.append(data[5])
                    lis6.append(data[6])
                    lis7.append(data[7])
                    lis8.append('https://www.zhipin.com'+data[8])

                    temp1=[]
                    temp1.append(int(min1))
                    temp1.append(int(max1))
                    price.append(temp1)
                # break
                if xx==10:
                    break

    f.close()
    lis=[lis1,lis2,lis3,lis4,lis5,lis6,lis7,lis8]
    lis111=[lis1,lis8]
    lis_text=[]
    for i in range(3):
        text=lis111[0][i]+'\t详细链接'+lis111[1][i]
        lis_text.append(text)
    text_all=lis_text[0]+'--'+lis_text[1]+'--'+lis_text[2]
    # 这里填写你在twilio.com上注册的账号  就可以发短信了
    # username="" #用户名
    # password="" #密码
    # client=Client(username,password)
    # mes=client.messages.create(
    #     from_='**********',  # 填写在active number处获得的号码
    #     body=text_all,
    #     to=number
    # )
    # print(mes)

    return lis,price

def show(lis):
    minp=[]
    maxp=[]
    avg=[]
    for i in lis:
        minp.append(i[0])
        maxp.append(i[1])

        avg.append((i[0]+i[1])/2)


    plt.figure(12)
    plt.subplot(221)
    plt.scatter(minp,maxp)

    plt.subplot(222)
    plt.bar([i for i in range(len(avg))],avg)
    plt.show()
