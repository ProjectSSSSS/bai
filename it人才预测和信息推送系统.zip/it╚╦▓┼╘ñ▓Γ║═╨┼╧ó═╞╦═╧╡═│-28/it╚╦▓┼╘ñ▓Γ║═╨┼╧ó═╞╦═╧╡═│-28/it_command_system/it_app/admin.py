from django.contrib import admin
from .models import Host,Answer
# Register your models here.
admin.site.register(Host)
admin.site.register(Answer)