from django.shortcuts import render
from .other import deal
# Create your views here.
def index(request):
    context={}
    if request.method=='POST':
        minprice=request.POST['minprice']
        maxprice=request.POST['maxprice']
        p_type=request.POST.get('p_type')
        city=request.POST.get('addr')
        position=request.POST.get('position')
        number=request.POST['number']
        li,price=deal.judge(minprice,maxprice,p_type,city,position,number)
        #print(minprice)
        # lis=data.data(int(minprice.split('.')[0]),int(maxprice.split('.')[0]),city,pname,name)
        # #print(lis)
        print(li)
        deal.show(price)
        context={'lis1':li[0],'lis2':li[1],'lis3':li[2],'lis4':li[3],'lis5':li[4],'lis6':li[5],'lis7':li[6],'lis8':li[7]}

    return render(request,'it_app/系统界面.html',context)
