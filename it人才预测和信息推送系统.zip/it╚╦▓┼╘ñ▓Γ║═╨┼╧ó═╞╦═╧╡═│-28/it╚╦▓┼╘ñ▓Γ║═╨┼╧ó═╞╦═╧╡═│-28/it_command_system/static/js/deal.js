﻿
    	// 创建一个二维数组
                var arr=new Array(30);
                arr[0] = ["后端开发", "后端开发", "Java", "C++", "PHP", "数据挖掘", "C", "C#", ".NET", "Hadoop", "Python", "Delphi", "VB", "Perl", "Ruby", "Node.js", "搜索算法", "Golang", "自然语言处理", "推荐算法", "Erlang", "算法工程师", "语音/视频/图形开发", "数据采集"];
                arr[1] = ['移动开发', 'HTML5', 'Android', 'iOS', 'WP', '移动web前端', 'Flash', 'JavaScript', 'U3D', 'COCOS2DX'];
                arr[2]=['测试', '测试工程师', '自动化测试', '功能测试', '性能测试', '测试开发', '移动端测试', '游戏测试', '硬件测试', '软件测试'];
                arr[3]=['运维/技术支持', '运维工程师', '运维开发工程师', '网络工程师', '系统工程师', 'IT技术支持', '系统管理员', '网络安全', '系统安全', 'DBA'];
                arr[4]=['数据', 'ETL工程师', '数据仓库', '数据开发', '数据分析师', '数据架构师', '算法研究员'];
                arr[5]=['项目管理', '项目经理', '项目主管', '项目助理', '项目专员', '实施顾问', '实施工程师', '需求分析工程师'];
                arr[6]=['硬件开发', '硬件', '嵌入式', '自动化', '单片机', '电路设计', '驱动开发', '系统集成', 'FPGA开发', 'DSP开发', 'ARM开发', 'PCB工艺', '模具设计', '热传导', '材料工程师', '精益工程师', '射频工程师'];
                arr[7]=['前端开发', 'web前端', 'Javascript','Flash','HTML5'];
                arr[8]=['通信', '通信技术工程师', '通信研发工程师', '数据通信工程师', '移动通信工程师', '电信网络工程师', '电信交换工程师', '有线传输工程师', '无线射频工程师', '通信电源工程师', '通信标准化工程师', '通信项目专员', '通信项目经理', '核心网工程师', '通信测试工程师', '通信设备工程师', '光通信工程师', '光传输工程师', '光网络工程师'];
                arr[9]=['电子/半导体', '电子工程师', '电气工程师', 'FAE', '电气设计工程师'];
                arr[10]=['高端技术职位', '技术经理', '技术总监', '测试经理', '架构师', 'CTO', '运维总监', '技术合伙人'];
                arr[11]=['人工智能', '机器学习', '深度学习', '图像算法', '图像处理', '语音识别', '图像识别','算法研究员'];
                arr[12]=['软件销售支持', '售前工程师', '售后工程师'];
                arr[13]=['其他技术职位','其他技术职位'];
//

               function choose(val){
                    // 获取city的select
                    //window.alert("111")
                    var city = document.getElementById("city1");
                    // 获取option
                    var cityOp = city.getElementsByTagName("option");
                    // 设置可操作
                    city.disabled = false;
                    // 先删除，后添加
                    for (var i = 0; i < cityOp.length; i++) {
                        var op = cityOp[i];
                        // 删除option
                        city.removeChild(op);
                        //数组长度发生变化，需处理
                        i--;
                    }

                    // 遍历
                    for (var i = 0; i < arr.length; i++) {
                        //取一维数组
                        var arr1 = arr[i];
                        //取一维数组的第一个值
                        var firstVal = arr1[0];
                        //判断
                        if(firstVal == val){
                            //遍历
                            for (var j = 1; j < arr1.length; j++) {
                                // 获取城市名
                                var value = arr1[j];
                                // 创建option
                                var optionl = document.createElement("option");
                                // 创建文本
                                var textl = document.createTextNode(value);
                                // 把文本添加到标签
                                optionl.appendChild(textl);
                                //添加到city里面
                                city.appendChild(optionl);
                            }
                        }
                    }
                }