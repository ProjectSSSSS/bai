from sklearn.cluster import KMeans
import numpy as np
from sklearn.preprocessing import StandardScaler
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.externals import joblib
from  matplotlib import pyplot as plt
class Bank:
    def getData(self,path):
        '''
        读取当前的数据集CSV文件
        :param path:
        :return:
        '''
        return pd.read_csv(path)
    #将用户属性划分为三大属性：
    #生活因素
    #银行离家距离，环境满意度，工作满意度，任职企业数，用户所在地区
    #个人因素
    # 性别，年龄，婚姻状况，工龄，学历
    #资产因素
    #估计现金总资产	开户时间	使用本行产品数量	是否有信用卡	活跃状况	账户最高余额	上一次交易日期

    #数据降维使用PCA
    def getFeature(self,data):
        pca=PCA(n_components=1)
        return pca.fit_transform(data)

    #对生活因素使用PCA降维
    def getLifeRelation(self,socure):
        #data=socure[['银行离家距离','环境满意度','工作满意度','任职企业数','性别','年龄','婚姻状况','工龄','学历','是否有信用卡']]
        data=socure[['使用本行产品数量','活跃状况','是否有信用卡','环境满意度','工作满意度','任职企业数','性别','年龄','工龄','学历']]
        return self.getFeature(data)

    #对个人因素进行PCA降维
    def getPersonRelation(self,source):
        data=source[['性别','年龄','婚姻状况','工龄','学历']]
        return self.getFeature(data)
    #对资金问题进行PCA降维
    def getFundRelation(self,source):
        data=source[['估计现金总资产','账户最高余额','使用时间长度','天数']]
        return self.getFeature(data)

    def peopleGroup(self,predict,id):
        '''
        分为5类人
        :return:
        '''
        res1=[]
        res2=[]
        res3=[]
        res4=[]
        res5=[]
        for i in range(len(predict)):
            if predict[i]==0:
                res1.append(id)
            elif predict[i]==1:
                res2.append(id)
            elif predict[i]==2:
                res3.append(id)
            elif predict[i]==3:
                res4.append(id)
            elif predict[i]==4:
                res5.append(id)
        # res=[res1,res2,res3,res4,res5]
        return res1,res2,res3,res4,res5
    def env_deal(self,df):
        for i in range(len(df)):
            if df[i] == '中':
                df[i] = int(1)
            elif df[i] == '低':
                df[i] = int(2)
            elif df[i] == '高':
                df[i] = int(3)
            elif df[i] == '非常高':
                df[i] = int(4)
        # print(df)
        return pd.to_numeric(df)
    def sex(self,df):
        for i in range(len(df)):
            if df[i]=='男':
                df[i]=1
            elif df[i]=='女':
                df[i]=2
        return pd.to_numeric(df)

    def study(self,df):
        for i in range(len(df)):
            if df[i]=='高中':
                df[i]=2
            elif df[i]=='初中以下':
                df[i]=1
            elif df[i]=='大学':
                df[i]=3
            elif df[i]=='大学以上':
                df[i]=4
            elif df[i]=='5':
                df[i]=5
        return pd.to_numeric(df)
    def married(self,df):
        for i in range(len(df)):
            if df[i]=='未婚':
                df[i]=1
            elif df[i]=='已婚':
                df[i]=2
            elif df[i]=='离婚':
                df[i]=3
        return pd.to_numeric(df)
    def predict(self,sf,km):
        print(km)
        df = self.getData("bank_csv.csv")
        id = df['id']
        # 计算最近一次的活跃天数
        df['天数'] = pd.to_datetime('today') - pd.to_datetime(df['上一次交易日期'])

        # #获取三类判断客户的评判标准
        # df['环境满意度']=self.env_deal(df['环境满意度'])
        # df['工作满意度']=self.env_deal(df['工作满意度'])
        # df['性别']=self.sex(df['性别'])
        # df['学历']=self.study(df['学历'])
        # df['婚姻状况']=self.married(df['婚姻状况'])
        # df.to_csv('bank_csv.csv')
        df['使用时间长度'] = pd.to_datetime(df['天数']) - pd.to_datetime(df['开户时间'])
        df['天数'] = (df['天数'] / np.timedelta64(1, 'D')).astype(int)
        df['使用时间长度'] = (df['使用时间长度'] / np.timedelta64(1, 'D')).astype(int)
        life_feature = self.getLifeRelation(df)
        # person_feature=self.getPersonRelation(df)
        fund_feature = self.getFundRelation(df)
        # data=np.append(life_feature,person_feature,axis=1)
        data_all = np.append(life_feature, fund_feature, axis=1)
        sdScaler = StandardScaler()
        res_data = sdScaler.fit_transform(data_all)
        km = KMeans(n_clusters=5)
        model = km.fit_transform(res_data)
        joblib.dump(model, 'bank_km.pkl')
        center = km.cluster_centers_
        # print("聚类的五个中心分别为：")
        #         for i in range(len(center)):
        #     print(center[i])  # 将源数据集进行分类

        predict = km.predict(sf)

        return predict
    def main(self):
        df=self.getData("bank_csv.csv")
        id=df['id']
        #计算最近一次的活跃天数
        df['天数']=pd.to_datetime('today')-pd.to_datetime(df['上一次交易日期'])

        # #获取三类判断客户的评判标准
        # df['环境满意度']=self.env_deal(df['环境满意度'])
        # df['工作满意度']=self.env_deal(df['工作满意度'])
        # df['性别']=self.sex(df['性别'])
        # df['学历']=self.study(df['学历'])
        # df['婚姻状况']=self.married(df['婚姻状况'])
        # df.to_csv('bank_csv.csv')
        df['使用时间长度']=pd.to_datetime(df['天数'])-pd.to_datetime(df['开户时间'])
        df['天数']=(df['天数']/np.timedelta64(1, 'D')).astype(int)
        df['使用时间长度']=(df['使用时间长度']/np.timedelta64(1, 'D')).astype(int)
        life_feature=self.getLifeRelation(df)
        #person_feature=self.getPersonRelation(df)
        fund_feature=self.getFundRelation(df)
        #data=np.append(life_feature,person_feature,axis=1)
        data_all=np.append(life_feature,fund_feature,axis=1)
        sdScaler=StandardScaler()
        res_data=sdScaler.fit_transform(data_all)
        km=KMeans(n_clusters=5)
        model=km.fit_transform(res_data)
        joblib.dump(model,'bank_km.pkl')
        center=km.cluster_centers_
        print("聚类的五个中心分别为：")
        for i in range(len(center)):
            print(center[i])  # 将源数据集进行分类

        predict = km.predict(res_data[200:400])
        res1, res2, res3, res4, res5 = self.peopleGroup(predict, id)

        print("*" * 20 + "以下为源数据集分类部分" + "*" * 20)
        print("第一类：\r\n一共%d人" % (len(res1)))
        print("第二类：\r\n一共%d人" % (len(res2)))
        print("第三类：\r\n一共%d人" % (len(res3)))
        print("第四类：\r\n一共%d人" % (len(res4)))
        print("第五类：\r\n一共%d人" % (len(res5)))
        print("*" * 50)
        fig, ax1 = plt.subplots( figsize=(14, 6))
        #print(res_data)
        ax1.scatter(res_data[:, 0], res_data[:, 1], c=km.labels_.astype(np.float))
        ax1.set_xlabel("$x_1$")
        ax1.set_ylabel("$x_2$")
        ax1.set_title("K-Means with $k=5$")
        plt.show()
        #print(len(res1))
        # x1=[]
        #
        # for i in res1:
        #     #print(i)
        #     # print(len(res_data[i-1][:]))
        #     # x1.append(res_data[i-1])
        # #print(x1)
        # ax2.scatter(x1[:,0],x1[:,1])
        # ax2.set_xlabel("$x_1$")
        # ax2.set_ylabel("$x_2$")
        # ax2.set_title("K-Means with $k=3$")
        # plt.show()

# if __name__=='__main__':
#     b=Bank()
#     b.main()