# encoding:utf-8


import tkinter as tk
import tkinter.messagebox
import pickle
from kmeans import Bank
from sklearn.externals import joblib
import pandas as pd
import numpy as np
from  sklearn.preprocessing import StandardScaler

#
# def person():




#
# def alluser():
#     pass

window=tk.Tk()
bank=Bank()
dic={1:'一般流失预警用户:一般这一类用户的资产水平较低，但是在与银行的互动和生活方面比较积极。建议:银行增加理财等项目，增加互动',2:'流失用户:这类用户的生活压力比较大资产水平较低容易流失',3:'重点客户:这类用户的资金比较充裕，生活压力小需要重点维持',4:'重点挽回用户：这类用户资产水平较高，在与银行的互动方面表现的不太积极银行需要加强与用户的互动',5:'即将流失客户:这类用户资产和生活压力比较偏大,即将流失银行需要针对此类用户提出一些低成本的理财产品，多与用户建立联系'}
window.title('银行客户信息挖掘与处理系统')
# window.geometry('800x800')
canvas=tk.Canvas(window,height=300,width=500)
imageFile=tk.PhotoImage('backgroud.jpg')
image=canvas.create_image(0,0,anchor='nw',image=imageFile)
canvas.pack(side='top')
#tk.Label(window,text='银行客户信息挖掘与处理系统',font=("黑体", 20, "bold")).place(x=50,y=30)


def person_predit():
    # lis=[]
    a = var1.get()

    # print(type(a))
    lis = [[var1.get(), var2.get(), var3.get(), var4.get(), var5.get(), var6.get(),
            var7.get(), var8.get(), var9.get(), var10.get(), var11.get(), var12.get(),
            var13.get(), var14.get(), var15.get(), var16.get(), var17.get(), var18.get(),
            var19.get()]]
    name = ['性别', '年龄', '学历', '婚姻状况', '月收入', '工龄', '估计现金总资产', '开户时间', '使用本行产品数量', '是否有信用卡', '活跃状况', '账户最高余额',
            '上一次交易日期',
            '银行离家距离', '环境满意度', '工作满意度', '任职企业数', '信用分数', '用户所在地区']
    df = pd.DataFrame(columns=name, data=lis)

    md = Bank()
    # print(df)
    df['天数'] = pd.to_datetime('today') - pd.to_datetime(df['上一次交易日期'])
    # print(df['天数'])
    # print(111111)
    # print(df['上一次交易日期'])
    df['环境满意度'] = md.env_deal(df['环境满意度'])
    df['工作满意度'] = md.env_deal(df['工作满意度'])
    df['性别'] = md.sex(df['性别'])
    df['学历'] = md.study(df['学历'])
    df['婚姻状况'] = md.married(df['婚姻状况'])
    # print(df['开户时间'])
    df['使用时间长度'] = pd.to_datetime(df['天数']) - pd.to_datetime(df['开户时间'])
    # print(df['天数'])
    df['天数'] = (df['天数'] / np.timedelta64(1, 'D')).astype(int)
    df['使用时间长度'] = (df['使用时间长度'] / np.timedelta64(1, 'D')).astype(int)
    life_feature = md.getLifeRelation(df)
    # person_feature=self.getPersonRelation(df)
    fund_feature = md.getFundRelation(df)
    # data=np.append(life_feature,person_feature,axis=1)
    data_all = np.append(life_feature, fund_feature, axis=1)
    sdScaler = StandardScaler()
    res_data = sdScaler.fit_transform(data_all)
    km = joblib.load('bank_km.pkl')
    pred = bank.predict(res_data,km)
    res1, res2, res3, res4, res5 = md.peopleGroup(pred, 'yes')
    if len(res1) != 0:
        window = tk.Tk()
        window.geometry('1200x200')
        data=dic[1].split('\n')
        tk.Label(window, text=data[0], font=("黑体", 12, "bold")).place(x=150, y=30)
        tk.Label(window, text=data[1], font=("黑体", 12, "bold")).place(x=150, y=60)
        tk.Label(window, text=data[2], font=("黑体", 12, "bold")).place(x=150, y=90)
        window.mainloop()
    elif len(res2) != 0:
        window = tk.Tk()
        window.geometry('1200x200')
        data = dic[2].split('\n')
        tk.Label(window, text=data[0], font=("黑体", 12, "bold")).place(x=150, y=30)
        tk.Label(window, text=data[1], font=("黑体", 12, "bold")).place(x=150, y=60)
        tk.Label(window, text=data[2], font=("黑体", 12, "bold")).place(x=150, y=90)
        window.mainloop()
    elif len(res3) != 0:
        window = tk.Tk()
        window.geometry('1200x200')
        data = dic[3].split('\n')
        tk.Label(window, text=data[0], font=("黑体", 12, "bold")).place(x=150, y=30)
        tk.Label(window, text=data[1], font=("黑体", 12, "bold")).place(x=150, y=60)
        tk.Label(window, text=data[2], font=("黑体", 12, "bold")).place(x=150, y=90)
        window.mainloop()
    elif len(res4) != 0:
        window = tk.Tk()
        window.geometry('1200x200')
        data = dic[4].split('\n')
        tk.Label(window, text=data[0], font=("黑体", 12, "bold")).place(x=150, y=30)
        tk.Label(window, text=data[1], font=("黑体", 12, "bold")).place(x=150, y=60)
        tk.Label(window, text=data[2], font=("黑体", 12, "bold")).place(x=150, y=90)
        window.mainloop()
    elif len(res5) != 0:
        window = tk.Tk()
        window.geometry('1200x200')
        data = dic[5].split('\n')
        tk.Label(window, text=data[0], font=("黑体", 12, "bold")).place(x=150, y=30)
        tk.Label(window, text=data[1], font=("黑体", 12, "bold")).place(x=150, y=60)
        tk.Label(window, text=data[2], font=("黑体", 12, "bold")).place(x=150, y=90)
        window.mainloop()


var1 = tk.StringVar()
var2 = tk.StringVar()
var3 = tk.StringVar()
var4 = tk.StringVar()
var5 = tk.IntVar()
var6 = tk.IntVar()
var7 = tk.IntVar()
var8 = tk.StringVar()
var9 = tk.IntVar()
var10 = tk.IntVar()
var11 = tk.IntVar()
var12 = tk.DoubleVar()
var13 = tk.StringVar()
var14 = tk.IntVar()
var15 = tk.StringVar()
var16 = tk.StringVar()
var17 = tk.IntVar()
var18 = tk.IntVar()
var19 = tk.StringVar()
# window = tk.Tk()
#window.title('个人信息分类及策略制定(单人信息)')
window.geometry('600x700')

tk.Label(window, text='个人信息分类及策略制定\n(单人信息)', font=("黑体", 20, "bold")).place(x=150, y=30)
tk.Label(window, text='性别:').place(x=70, y=140)
tk.Label(window, text='年龄:').place(x=370, y=140)
tk.Label(window, text='学历:').place(x=70, y=190)
tk.Label(window, text='婚姻状况:').place(x=350, y=190)
tk.Label(window, text='月收入:').place(x=60, y=240)
tk.Label(window, text='工龄:').place(x=370, y=240)
tk.Label(window, text='估计现金总资产:').place(x=20, y=290)
tk.Label(window, text='开户时间:').place(x=350, y=290)
tk.Label(window, text='使用本行产品数量:').place(x=10, y=340)
tk.Label(window, text='是否有信用卡:').place(x=330, y=340)
tk.Label(window, text='活跃状况:').place(x=50, y=390)
tk.Label(window, text='账户最高余额:').place(x=330, y=390)
tk.Label(window, text='上一次交易日期:').place(x=20, y=440)
tk.Label(window, text='银行离家距离:').place(x=330, y=440)
tk.Label(window, text='环境满意度:').place(x=40, y=490)
tk.Label(window, text='工作满意度:').place(x=340, y=490)
tk.Label(window, text='任职企业数:').place(x=40, y=540)
tk.Label(window, text='信用分数:').place(x=350, y=540)
tk.Label(window, text='用户所在地区:').place(x=30, y=590)
# var1 = tk.StringVar()
ent1_sex = tk.Entry(window, textvariable=var1)
ent1_sex.place(x=120, y=140)
# var2 = tk.StringVar()
ent1_age = tk.Entry(window, textvariable=var2)
ent1_age.place(x=420, y=140)
# var3 = tk.StringVar()
ent1_study = tk.Entry(window, textvariable=var3)
ent1_study.place(x=120, y=190)
# var4 = tk.StringVar()
ent1_marr = tk.Entry(window, textvariable=var4)
ent1_marr.place(x=420, y=190)
# var5 = tk.IntVar()
ent1_shouru = tk.Entry(window, textvariable=var5)
ent1_shouru.place(x=120, y=240)
# var6 = tk.IntVar()
ent1_wage = tk.Entry(window, textvariable=var6)
ent1_wage.place(x=420, y=240)
# var7 = tk.IntVar()
ent1_crush = tk.Entry(window, textvariable=var7)
ent1_crush.place(x=120, y=290)
# var8 = tk.StringVar()
ent1_start = tk.Entry(window, textvariable=var8)
ent1_start.place(x=420, y=290)
# var9 = tk.IntVar()
ent1_nums = tk.Entry(window, textvariable=var9)
ent1_nums.place(x=120, y=340)
# var10 = tk.IntVar()
ent1_card = tk.Entry(window, textvariable=var10)
ent1_card.place(x=420, y=340)
# var11 = tk.IntVar()
ent1_huoyue = tk.Entry(window, textvariable=var11)
ent1_huoyue.place(x=120, y=390)
# var12 = tk.IntVar()
ent1_maxPrice = tk.Entry(window, textvariable=var12)
ent1_maxPrice.place(x=420, y=390)
# var13 = tk.StringVar()
ent1_lastDate = tk.Entry(window, textvariable=var13)
ent1_lastDate.place(x=120, y=440)
# var14 = tk.IntVar()
ent1_distance = tk.Entry(window, textvariable=var14)
ent1_distance.place(x=420, y=440)
# var15 = tk.StringVar()
ent1_env = tk.Entry(window, textvariable=var15)
ent1_env.place(x=120, y=490)
# var16 = tk.StringVar()
ent1_work = tk.Entry(window, textvariable=var16)
ent1_work.place(x=420, y=490)
# var17 = tk.IntVar()
ent1_company = tk.Entry(window, textvariable=var17)
ent1_company.place(x=120, y=540)
# var18 = tk.IntVar()
ent1_score = tk.Entry(window, textvariable=var18)
ent1_score.place(x=420, y=540)
# var19 = tk.StringVar()
ent1_addr = tk.Entry(window, textvariable=var19)
ent1_addr.place(x=120, y=590)

button1 = tk.Button(window, text='信息分类及策略制定', command=person_predit)
button1.place(x=120, y=640)
button2 = tk.Button(window, text='模型聚类结果展示', command=bank.main)
button2.place(x=320, y=640)
window.mainloop()

# button1=tk.Button(window,text='个人信息分类及策略制定(单人信息)',command=person)
# button1.place(x=100,y=90)
#
# button2=tk.Button(window,text='多用户信息分类及策略制定(多人信息)',command=alluser)
# button2.place(x=100,y=180)
# window.mainloop()